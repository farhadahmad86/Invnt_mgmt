<?php

namespace App\Http\Controllers;

use App\Models\CompanyProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CompanyProfileController extends Controller
{
    public function company_profile(){
        $company_profile = CompanyProfile::where('cp_id',1)->first();
        return view('company_profile',compact('company_profile'));
    }
    public function update_company_profile(Request $request){


        $company_profile = CompanyProfile::where('cp_id','=',1)->first();

        $company_profile->cp_name = $request->name;
        $company_profile->cp_salogan = $request->salogan;
        $company_profile->cp_address = $request->address;
        $company_profile->cp_terms = $request->terms;
        $company_profile->cp_deal = $request->deal_in;
        $company_profile->cp_contact = $request->contact;
        $company_profile->cp_contact = $request->contact;
        // $company_profile->cp_logo = $request->logo;
        $save_image = new SaveImageController();
        // $uniqueId = Utility::uniqidReal() . mt_rand();
        $common_path = config('global_variables.common_path');
        $product_path = config('global_variables.product_path');

        // Handle Image
        $fileNameToStore = $save_image->SaveImage($request, 'logo', $product_path, 'Product_Image');


        if ($request->hasFile('logo')) {
            $company_profile->cp_logo = $common_path . $fileNameToStore;
        } else {
            $company_profile->pro_logo = $fileNameToStore;
        }
        // if (!empty($request->logo)) {
        //     // $save_image = new SaveImageController();

        //     $common_path = config('global_variables.common_path');
        //     $company_path = config('global_variables.company_logo');

        //     // Handle Image
        //     // $fileNameToStore = $save_image->SaveImage($request, 'logo', $request->folder, $company_path, 'logo34');

        //     // $company->ci_logo = $common_path . $fileNameToStore;


		//     $imageName = rand( 11111, 99999 ) . '.' . request()->logo->getClientOriginalExtension();

		//     Storage::put('/company_logo/'.$imageName,file_get_contents($request->file('logo')));

        //     $company_profile->cp_logo = $common_path.'/company_logo/'.$imageName;


        // }
        $company_profile->save();
        return redirect()->route('company_profile');
    }
}
